CREATE DATABASE EmployeeDB;
CREATE TABLE Employee(id INT,name VARCHAR(50),dept_id INT,salary INT);
CREATE TABLE Department(id INT,name VARCHAR(50));
SELECT * FROM Employee;
SELECT * FROM Employee WHERE salary>50000;
SELECT COUNT(*) FROM Employee;
SELECT d.name,COUNT(*) FROM Employee e JOIN Department d ON e.dept_id=d.id GROUP BY d.name;
